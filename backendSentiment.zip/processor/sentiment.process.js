var Sentiment = require('sentiment');
var sentiment = new Sentiment();

  exports.getSentiment = function(message, id){

    var result = [];

      console.log("--------------------");
      console.log("--------------------");
      console.log("Inside sentiment.process.js");
      console.log("getSentiment message");
      console.log(message);
      
      var result1 = sentiment.analyze(message);
      
      console.log("--------------------");
      console.log("sentiment.analyze");
      console.log(result1);

      result[0]             = id;
      result[1]             = result1["score"];
      result[2]             = result1["comparative"];
      result[3]             = result1["tokens"].join("-++-");
      result[4]             = result1["words"].join("-++-");
      result[5]             = result1["positive"].join("-++-");
      result[6]             = result1["negative"].join("-++-");

      // var result = Object.keys(result1).map(function(key) { return result1[key];});
      console.log("result")
      console.log(result);
      return result;
    };