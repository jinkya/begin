INSERT INTO dogs(id, name, breed, age) VALUES (101, 'Alpha', 'German Shepherd',3 ),
			                                  (102, 'Bravo', 'Labrador', 4),
                                              (103, 'Charlie', 'Bulldog', 1),
											  (104, 'Delta', 'Poodle', 6),
                                              (105, 'Echo', 'Beagle', 5),
					                          (106, 'Foxtrot', 'Golden retriver', 1),
					                          (107, 'Golf', 'Chuhuahua', 4),
					                          (108, 'Hotel', 'Pug', 3),
					                          (109, 'India', 'Pit Bull',2 ),
					                          (110, 'Juliette', 'Siberian Husky',3 )



-- SELECT ALL SCHEMAS
select schema_name AS schemas from information_schema.schemata

-- SELECT ALL TABLES IN A PATICULAR SCHEMA
SELECT table_name FROM information_schema.tables WHERE table_schema='public'

-- CREATE SCHEMA
-- CREATE SCHEMA IF NOT EXISTS schema_name [ AUTHORIZATION user_name ]
CREATE SCHEMA IF NOT EXISTS mark01 AUTHORIZATION postgres

CREATE TABLE mark01.demo01(
	a TEXT,
	b INTEGER
)

select * from dogs

## Modules
1. inert 		-	to serve static pages.
2. Boom 		-	HTTP-friendly error objects
3. lokijs		-	document oriented databse
4. uuid 		-	Simple and fast generation of UUIDs
5. del 			-	delete files and folders


==============================================================================================
Implementing authentication
==============================================================================================

==============================================================================================
Geo Locating
==============================================================================================
geo locate requests by IP
Uses https://ipinfo.io/
npm i -S hapi-geo-locate
==============================================================================================

==============================================================================================
tv
==============================================================================================
server requests log 

==============================================================================================