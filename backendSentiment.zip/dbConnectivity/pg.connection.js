const ENV = require('../env/env');

const { Pool, Client } = require('pg');
const connectionString = ENV.pgURL;
exports.pool = new Pool({
  connectionString: connectionString,
})