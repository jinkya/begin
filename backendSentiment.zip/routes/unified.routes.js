const DogRoutes = require('./dog.routes');
const DBRoutes  = require('./database.routes');

/*const oneRoute = Array.prototype.push.apply(DogRoutes, DBRoutes);*/

module.exports = [].concat(DogRoutes, DBRoutes);