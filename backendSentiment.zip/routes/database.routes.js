const PGDBController = require('../controllers/database.controller');
const Joi = require('joi');

/*const schema = Joi.object().keys({
				breed  :  Joi.string().alphanum().min(3).max(25).required()
			});*/

module.exports =[

				{
    				method: 'GET',
    				path: '/pgdb',
    				handler: PGDBController.listSchemasPG,
    				options: {      			
    							tags: ['api'],
        						description: 'GET ALL SCHEMAS',
        						notes: 'Get all the Schemas',
    							}
    				},

    			    {
    				method: 'GET',
    				path: '/pgdb/{schema}',
    				handler: PGDBController.getTablesPG,
    				options: {
    							tags: ['api'],
                	            description: 'GET TABLES by SCHEMA_NAME',
                	            notes: 'Get tables by schema_name',
    				  			validate:{
                						params: Joi.object().keys({
                	    											schema: Joi.string().required()
                												})
            							}
    						}
  					}
]