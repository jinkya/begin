const del      = require('del');
const Loki     = require('lokijs');
const fs       = require('fs');
const uuid     = require('uuid');

exports.loadCollection = function (colName, db) {
    return new Promise(function (resolve) {
        db.loadDatabase({}, function () {
            var _collection = db.getCollection(colName) || db.addCollection(colName);
            resolve(_collection);
        });
    });
};

exports.uploader = function (file, options) {
    if (!file)
        throw new Error('no file(s)');
    return _fileHandler(file, options);
};
var _fileHandler = function (file, options) {
    if (!file)
        throw new Error('no file');
    var orignalname = file.hapi.filename;
    var filename = uuid.v1();
    var path = "" + options.dest + filename;
    var fileStream = fs.createWriteStream(path);
    return new Promise(function (resolve, reject) {
        file.on('error', function (err) {
            reject(err);
        });
        file.pipe(fileStream);
        file.on('end', function (err) {
            var fileDetails = {
                fieldname: file.hapi.name,
                originalname: file.hapi.filename,
                filename: filename,
                mimetype: file.hapi.headers['content-type'],
                destination: "" + options.dest,
                path: path,
                size: fs.statSync(path).size,
            };
            resolve(fileDetails);
        });
    });
};

/*export { loadCollection, uploader }*/