const DBQRY =  require('../queries/database.query');
const ENV    =  require('../env/env');
const DB     =  require('../dbConnectivity/pg.connection');

const pool = DB.pool;

exports.listSchemasPG = (req, h) => {
  return (async () => {
                const client = await pool.connect();
                try {
                  const res = await client.query(DBQRY.query0);
                              var values = res.rows;
                              var tables = [];
                              values.forEach( x => tables.push(x['schemas']));
                  return { rowCount: res.rowCount, schemas: tables };
                } finally {
                  client.release();
                }
          })().catch(e => console.log(e.stack))
};

exports.getTablesPG = (req, h) => {
  return (async () => {
                const client = await pool.connect();
                try {
                  const res = await client.query(DBQRY.query1, [req.params.schema]);
                              var values = res.rows;
                              var tables = [];
				                      values.forEach( a => tables.push(a['table_name']));
				          console.log(tables);
                  return { rowCount: res.rowCount, tables: tables };
                } finally {
                  client.release();
                }
          })().catch(e => console.log(e.stack))
};