const DOGQRY              =  require('../queries/dog.query');
const ENV                 =  require('../env/env');
const DB                  =  require('../dbConnectivity/pg.connection');
const SENTIMENTPROCESSOR  = require('../processor/sentiment.process');

const pool = DB.pool;

/**
 * List Dogs
 */

exports.listDogsPG = (req, h) => {
  return (async () => {
                const client = await pool.connect();
                try {
                  const res = await client.query(DOGQRY.query0);
                  return { rowCount: res.rowCount, dogs: res.rows };
                } finally {
                  client.release();
                }
          })().catch(e => console.log(e.stack))
}

/**
 * Get Dog by ID
 */

exports.getDogsPG = (req, h) => {
  return (async () => {
                const client = await pool.connect()
                try {
                  const res = await client.query(DOGQRY.query1, [encodeURIComponent(req.params.id)]);
                  console.log(req.params.id);
                  console.log(encodeURIComponent(req.params.id));
                  return { rowCount: res.rowCount, dogs: res.rows };
                } finally {
                  client.release();
                }
          })().catch(e => console.log(e.stack))
}

/**
 * POST a Dog
 */
exports.createDogsPG = (req, h) => {
  const dogData = [
    id            = req.payload.id,
    name          = req.payload.name,
    breed         = req.payload.breed,
    age           = req.payload.age,
    message       = req.payload.message,
    imageURL      = req.payload.imageURL,
    location_lat  = req.payload.location_lat,
    location_long = req.payload.location_long
  ];

  return (async () => {
                const client = await pool.connect()
                try {
                  console.log("-------------------------------");
                  console.log("-------------------------------");
                  console.log("Inside dog.controller.js");
                  console.log("dogData");
                  console.log(dogData);
                  var sentiments = SENTIMENTPROCESSOR.getSentiment(dogData[4], dogData[0]);
                  console.log("-------------------------------");
                  console.log("Processed sentiments");
                  console.log(sentiments);
                  const res1 = await client.query(DOGQRY.query2, dogData);
                  const res2 = await client.query(DOGQRY.query5, sentiments);
                  console.log(DOGQRY.query5);
                  res = res1+res2;
                  console.log("-------------------------------");
                  console.log(res);
                  return res;
                } finally {
                  client.release();
                }
          })().catch(e => console.log(e.stack))
}

/**
 * Delete Dog by ID
 */
exports.removeDogsPG = (req, h) => {
  console.log(req.params.id);

    return (async () => {
                const client = await pool.connect()
                try {
                  const res = await client.query(DOGQRY.query4, [encodeURIComponent(req.params.id)]);
                  return res;
                } finally {
                  client.release();
                }
          })().catch(e => console.log(e.stack))

}

/**
 * PUT | Update Dog by ID
 */
exports.updateDogsPG = (req, h) => {
  return (async () => {
                const client = await pool.connect()
                try {
                  const res = await client.query(DOGQRY.query3, [req.params.id, req.payload.id, req.payload.name,req.payload.breed,req.payload.age, req.payload.message] );
                  return res;
                } finally {
                  client.release();
                }
          })().catch(e => console.log(e.stack))
}

/**
 * List Dogs Sentiment COunt
 */

exports.listDogsSntimentCount = (req, h) => {
  return (async () => {
                const client = await pool.connect();
                try {
                  const res1 = await client.query(DOGQRY.query6);
                  const res2 = await client.query(DOGQRY.query7);
                  const res3 = await client.query(DOGQRY.query8);
                  const res4 = await client.query(DOGQRY.query9);
                  return { dog_sentiment_total_count: res1.rows[0]["count"], dog_sentiment_neutral_count: res2.rows[0]["count"], dog_sentiment_negative_count: res3.rows[0]["count"], dog_sentiment_positive_count: res4.rows[0]["count"]};
                } finally {
                  client.release();
                }
          })().catch(e => console.log(e.stack))
}