module.exports ={
	query0 : 'SELECT * FROM dogs',
	query1 : 'SELECT * FROM dogs WHERE id = $1',
	query2 : 'INSERT INTO dogs(id, name, breed, age, message, imageURL, location_lat, location_long) VALUES($1,$2,$3,$4,$5,$6,$7,$8)',
	query3 : 'UPDATE dogs SET id= $1, name= $2, breed= $3, age=$4, message=$5 WHERE id= $6',
	query4 : 'DELETE FROM dogs WHERE id= $1',
	query5 : 'INSERT INTO dogsentiment(id, score, comparative, tokens, words, positive, negative) VALUES($1,$2,$3,$4,$5,$6,$7)',
	
	query6 : 'select COUNT(score) from dogsentiment',
	query7 : 'select COUNT(score) from dogsentiment where score=0',
	query8 : 'select COUNT(score) from dogsentiment where score<0',
	query9 : 'select COUNT(score) from dogsentiment where score>0',

	query10 : 'select sum(score) as total_sentiment_count from dogsentiment',
	query11 : 'select sum(score) as neutral_sentiment_count from dogsentiment where score=0',
	query12 : 'select sum(score) as negative_sentiment_count from dogsentiment where score<0',
	query13 : 'select sum(score) as positive_sentiment_count from dogsentiment where score>0',
}


// Images URL
/*
finnish-spitz							https://bit.ly/2E4INCS
dogue-de-bordeaux						https://bit.ly/2E4bcZL
cavalier-king-charles-spaniel			https://bit.ly/2RwSOvm
appenzeller-sennenhunde					https://bit.ly/2y3TSOX
alaskan-klee-kai-breed					https://bit.ly/2zUO3Vp
american-bulldog-breed					https://bit.ly/2zV6Ujb
bolognese								https://bit.ly/2y2PEaw
pug										
saluki									
shiba-inu								
small-munsterlander-pointer				https://bit.ly/2PhYhVl
welsh-terrier							https://bit.ly/2Qwx7tM


id 		name	breed 	age 	message 	imageurl

(101, "Alpha", 		"finnish-spitz", 				 5, "Today is the day, I can feel it. Today I will catch that tail.", 												"https://bit.ly/2E4INCS"),
(102, "Bravo", 		"dogue-de-bordeaux", 			 2, "Beware of the dog. He want cuddles", 							  												"https://bit.ly/2E4bcZL"),
(103, "Charlie", 	"cavalier-king-charles-spaniel", 3, "Football is an incredible game.", 								  												"https://bit.ly/2RwSOvm"),
(104, "Delta", 		"appenzeller-sennenhunde", 		 4, "I protect you.", 												  												"https://bit.ly/2y3TSOX"),
(105, "Echo", 		"alaskan-klee-kai-breed", 		 1, "My owner is a stupid person.", 								  												"https://bit.ly/2zUO3Vp"),
(106, "Foxtrot", 	"american-bulldog-breed",  		 5, "I dont always want to cuddle. But when I do, its when you are about to leave for workand wearing black pants", "https://bit.ly/2zV6Ujb"),
(107, "Golf", 		"bolognese", 					 3, "I dont always bark, but when I do, its in the middle of the night", 											"https://bit.ly/2y2PEaw"),
(108, "Hotel", 		"pug", 							 4, "Like a good neighbour, stay over there", 																		"https://bit.ly/2C3JZnc"),
(109, "India", 		"saluki", 						 5, "If I have said or done anything to hurt you, I dont care", 													"https://bit.ly/2PiBXLa"),
(110, "Juliett", 	"shiba-inu", 					 2, "I am feeling like cuddling.", 																					"https://bit.ly/2E2gnt3"),
(111, "Kilo", 		"small-munsterlander-pointer",   1, "Bho Bho", 																										"https://bit.ly/2PhYhVl"),
(112, "Lima", 		"welsh-terrier", 				 4, "ooooooooooooooo", 																								"https://bit.ly/2Qwx7tM"),

-- total count 
select COUNT(score) from dogsentiment
-- neutral count
select COUNT(score) from dogsentiment where score=0;
-- positive count
select COUNT(score) from dogsentiment where score<0;
-- negative count
select COUNT(score) from dogsentiment where score>0;



-- total sentiment sum
select sum(score) from dogsentiment
-- neutral sentiment sum
select sum(score) from dogsentiment where score=0
-- negative sentiment sum
select sum(score) from dogsentiment where score<0
-- positive sentiment sum
select sum(score) from dogsentiment where score>0
*/