module.exports = {
	query0 : 'select schema_name AS schemas from information_schema.schemata',
    query1 : 'SELECT table_name FROM information_schema.tables WHERE table_schema= $1',
    query2 : '',
    query3 : '',
    query4 : '',
    query5 : ''
}